# IKARUS — made by AyeJayS47 [IKARUS Software]
"""Pomodoro — focus rounds with breaks, on the dashboard, the island and in Spotlight.

  Home card     the time left, Start / Pause and Reset
  island        a live card counts down while a round runs; a peek says when it's done
  Spotlight     type "pomodoro" (or "focus"): start, pause or stop it from there
  games         a game starting pauses the round (Settings: "Pause while I play")
It ticks once a second ONLY while a round runs; at rest nothing runs."""
import time


def setup(api):
    st = {"phase": "ready", "end": 0.0, "left": 0.0, "tick": None, "game": False}   # phase: ready | focus | break
    ui = {}

    def minutes(key):
        return int(api.setting(key) or (25 if key == "work" else 5))

    def total():
        return minutes("rest" if st["phase"] == "break" else "work") * 60

    def left():
        if st["end"]:
            return max(0.0, st["end"] - time.monotonic())
        return st["left"] or float(total())

    def clock(sec):
        m, s = divmod(int(round(sec)), 60)
        return f"{m:02d}:{s:02d}"

    def show():
        running = bool(st["end"])
        name = {"ready": "Ready", "focus": "Focus", "break": "Break"}[st["phase"]]
        if ui:
            ui["time"].set_label(clock(left()))
            ui["what"].set_label(name + ("" if running or st["phase"] == "ready" else " · paused"))
            api.ui.set_text(ui["go"], "Pause" if running else "Start")
        if running:
            api.live(f"{name} · {clock(left())}", "Pomodoro", progress=min(0.999, 1 - left() / total()),
                     icon="chronometer-symbolic")
        elif st["phase"] != "ready":
            api.live(f"{name} · {clock(left())}", "Pomodoro · paused", progress=1 - left() / total())

    def tick():
        if left() > 0:
            show()
            return True
        if st["phase"] == "focus":                       # round done -> the break starts by itself
            st["phase"], st["left"] = "break", 0.0
            st["end"] = time.monotonic() + total()
            api.peek("Focus round done", f"Take {minutes('rest')} minutes, sir", icon="emblem-ok-symbolic")
            show()
            return True
        stop()
        api.peek("Break over", "Ready for the next round when you are", icon="chronometer-symbolic")
        return False

    def start(_v=""):
        if st["end"]:
            return
        if st["phase"] == "ready":
            st["phase"] = "focus"
        st["end"], st["left"] = time.monotonic() + left(), 0.0
        if st["tick"] is None:
            st["tick"] = api.every(1, tick)
        show()

    def pause(_v=""):
        if not st["end"]:
            return
        st["left"], st["end"] = left(), 0.0
        if st["tick"] is not None:
            st["tick"].stop()
            st["tick"] = None
        show()

    def stop(_v=""):
        pause()
        st.update(phase="ready", left=0.0, end=0.0)
        api.live_end()
        show()

    def toggle():
        pause() if st["end"] else start()

    def build():
        box = api.ui.box(spacing=6)
        ui["time"] = api.ui.label("", "big", wrap=False)
        ui["what"] = api.ui.label("", "dim", wrap=False)
        keys = api.ui.box(vertical=False, spacing=8)
        ui["go"] = api.ui.button("Start", on_click=toggle, primary=True)
        keys.append(ui["go"])
        keys.append(api.ui.button(icon="view-refresh-symbolic", on_click=stop, tip="Reset"))
        for w in (ui["time"], ui["what"], keys):
            box.append(w)
        show()
        return box

    def search(q):
        if st["end"]:
            return [{"title": f"Pause the pomodoro ({clock(left())} left)", "icon": "media-playback-pause-symbolic",
                     "action": "pause"},
                    {"title": "Stop the pomodoro", "icon": "media-playback-stop-symbolic", "action": "stop"}]
        return [{"title": f"Start a {minutes('work')} min focus round" if st["phase"] == "ready" else "Go on",
                 "sub": f"then a {minutes('rest')} min break", "icon": "chronometer-symbolic", "action": "start"}]

    def on_game(g):
        if not api.setting("game_pause"):
            return
        if g["running"] and st["end"]:
            st["game"] = True
            pause()
        elif not g["running"] and st["game"]:
            st["game"] = False
            start()

    api.card(build, title="Pomodoro", size="s", about="Focus rounds with breaks")
    api.spotlight(search, keywords=("pomodoro", "focus", "pomo"))
    for name, fn in (("start", start), ("pause", pause), ("stop", stop)):
        api.action(name, fn)
    api.on("game", on_game)
    api.on("settings", lambda _s: show())


def teardown():
    pass                                                 # (the island ends its ticks and its live card by itself)
