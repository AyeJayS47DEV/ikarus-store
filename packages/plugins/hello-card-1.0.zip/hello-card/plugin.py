# IKARUS — made by AyeJayS47 [IKARUS Software]
"""Hello card — the smallest useful IKARUS plugin: a Home card that greets you and shows what's playing.

Copy this folder to ~/.local/share/ikarus/plugins/<your-id>/, change "id" in plugin.json to the folder's name, and
make it yours. The guide: ~/IKARUS/apps/island/plugins/README.md. Nothing here ticks: the card refreshes when a song changes,
when you change its settings, and each time it comes on screen."""
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:                                      # for your editor only (~/IKARUS/apps/island/plugins/sdk on its search path)
    from ikarus_plugin_api import API


def setup(api: "API") -> None:
    shown = {}                                         # the card's labels, once Home has built it

    def greeting():
        h = time.localtime().tm_hour
        part = "morning" if 5 <= h < 12 else "afternoon" if 12 <= h < 18 else "evening"
        return f"Good {part}, {api.setting('name') or 'sir'}"

    def song_line():
        s = api.media()
        if not api.setting("show_song"):
            return ""
        if s["status"] != "Playing" or not s["title"]:
            return "Nothing playing"
        return f"♪ {s['title']}" + (f" — {s['artist']}" if s["artist"] else "")

    def refresh(*_a):
        if shown:
            shown["hi"].set_label(greeting())
            line = song_line()
            shown["song"].set_label(line)
            shown["song"].set_visible(bool(line))

    def build():
        box = api.ui.box(spacing=4)
        shown["hi"] = api.ui.label(greeting(), "big")
        shown["song"] = api.ui.label("", "dim")
        box.append(shown["hi"])
        box.append(shown["song"])
        box.connect("map", refresh)                    # fresh each time Home shows it (the time of day moves on)
        refresh()
        return box

    api.card(build, title="Hello", size="s", about="Says hello and shows what's playing")
    api.on("media", refresh)
    api.on("settings", refresh)
