# IKARUS — made by AyeJayS47 [IKARUS Software]
"""Now playing — a small example plugin: a Home card with the song, the artist and the album, and (if you switch it
on in its settings) a short pop-up on the island each time the song changes.

Nothing here ticks. IKARUS tells the plugin when the song changes (the "media" event), so the card costs nothing
while the music is stopped or Home is closed. The guide: ~/IKARUS/apps/island/plugins/README.md."""
from typing import TYPE_CHECKING

if TYPE_CHECKING:                                      # for your editor only (~/IKARUS/apps/island/plugins/sdk on its search path)
    from ikarus_plugin_api import API


def lines(song, album=True):
    """What the card says for one song -> (title, artist, album, state)."""
    title = str(song.get("title") or "")
    if not title or song.get("status") == "Stopped":
        return "Nothing playing", "", "", ""
    state = "Paused" if song.get("status") == "Paused" else "Playing"
    return title, str(song.get("artist") or ""), str(song.get("album") or "") if album else "", state


def setup(api: "API") -> None:
    shown = {}                                         # the card's labels, once Home has built it
    last = {"song": None}                              # the song the island last heard about

    def refresh(*_a):
        if not shown:
            return
        title, artist, album, state = lines(api.media(), bool(api.setting("album")))
        for key, text in (("title", title), ("artist", artist), ("album", album), ("state", state)):
            shown[key].set_label(text)
            shown[key].set_visible(bool(text))

    def changed(song):
        refresh()
        key = (song.get("title"), song.get("artist"))
        if song.get("status") == "Playing" and song.get("title") and key != last["song"]:
            if last["song"] is not None and api.setting("peek"):
                api.peek(song["title"], song.get("artist") or "Now playing", icon="audio-x-generic-symbolic")
            last["song"] = key

    def build():
        box = api.ui.box(spacing=3)
        shown["state"] = api.ui.label("", "small")
        shown["title"] = api.ui.label("", "title")
        shown["artist"] = api.ui.label("", "body")
        shown["album"] = api.ui.label("", "dim")
        for key in ("state", "title", "artist", "album"):
            box.append(shown[key])
        box.connect("map", refresh)                    # fresh each time Home shows it
        refresh()
        return box

    api.card(build, title="Now playing", size="s", about="The song, the artist and the album")
    api.on("media", changed)
    api.on("settings", refresh)
